export const routes = {
  index: '/',
  dummy: '',
  pageExample: '/page-example',
};
