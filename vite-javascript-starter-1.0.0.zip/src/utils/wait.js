export const wait = (time) => new Promise((res) => setTimeout(res, time));
